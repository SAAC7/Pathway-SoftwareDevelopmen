import pytest
import json
from build_sentences import (get_seven_letter_word, parse_json_from_file, choose_sentence_structure,
                              get_pronoun, get_article, get_word, fix_agreement, build_sentence, structures)

def test_get_seven_letter_word():
    pass

def test_parse_json_from_file():
    pass

def test_choose_sentence_structure():
    pass

def test_get_pronoun():
    pass

def test_get_article():
    pass

def test_get_word():
    pass

def test_fix_agreement():
    pass

def test_build_sentence():
    pass